import Booking from './models/Booking.js';

export const bookSalon = async (req, res) => {
  const { user, salon, services, amount, timeSlot } = req.body;
  const otp = Math.floor(100000 + Math.random() * 900000);
  const booking = await Booking.create({ user, salon, services, amount, timeSlot, otp });
  res.json({ message: 'Booking successful', booking });
};

export const getBookings = async (req, res) => {
  const bookings = await Booking.find().populate('user salon');
  res.json(bookings);
};

export const cancelBooking = async (req, res) => {
  await Booking.findByIdAndUpdate(req.params.id, { status: 'cancelled' });
  res.json({ message: 'Booking cancelled' });
};