import Salon from '../models/Salon.js';


export const getSalons = async (req, res) => {
  const salons = await Salon.find();
  res.json(salons);
};

export const getSalonById = async (req, res) => {
  const salon = await Salon.findById(req.params.id);
  res.json(salon);
};