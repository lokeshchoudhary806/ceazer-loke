import express from 'express';
const app = express();

app.use(express.json());

// Login route
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;

  // Yahan database se user check karoge
  if (email === 'test@example.com' && password === '123456') {
    res.json({ token: 'sampletoken123' });
  } else {
    res.status(401).json({ message: 'Invalid credentials' });
  }
});

// Salon list route - ye tumhare frontend ke liye hai
app.get('/api/salons', (req, res) => {
  const salons = [
    { name: 'Salon One', location: 'Mumbai', services: { haircut: 500, spa: 1500 } },
    { name: 'Salon Two', location: 'Delhi', services: { manicure: 700, pedicure: 800 } },
  ];
  res.json(salons);
});

const PORT = process.env.PORT || 5002;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
