import express from 'express';
import { getSalons, getSalonById } from '../controllers/salonController.js';
const router = express.Router();

router.get('/', getSalons);
router.get('/:id', getSalonById);

export default router;