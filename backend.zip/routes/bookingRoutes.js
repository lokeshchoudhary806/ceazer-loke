import express from 'express';
import { bookSalon, getBookings, cancelBooking } from '../controllers/bookingController.js';
const router = express.Router();

router.post('/', bookSalon);
router.get('/', getBookings);
router.put('/:id/cancel', cancelBooking);

export default router;