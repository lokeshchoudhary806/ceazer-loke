import mongoose from 'mongoose';

const bookingSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  salon: { type: mongoose.Schema.Types.ObjectId, ref: 'Salon' },
  services: [String],
  amount: Number,
  timeSlot: String,
  status: { type: String, default: 'upcoming' },
  otp: Number,
}, { timestamps: true });

export default mongoose.model('Booking', bookingSchema);