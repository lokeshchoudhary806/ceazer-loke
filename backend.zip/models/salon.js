import mongoose from 'mongoose';

const salonSchema = new mongoose.Schema({
  name: String,
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  address: String,
  location: String,
  phone: String,
  rating: Number,
  services: Object,
  timeSlots: [String],
});

export default mongoose.model('Salon', salonSchema);