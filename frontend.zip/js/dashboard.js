window.onload = async () => {
  const res = await fetch('http://localhost:5002/api/salons');
  const salons = await res.json();
  const container = document.getElementById('salonList');
  salons.forEach(s => {
    const div = document.createElement('div');
    div.textContent = `${s.name} - ${s.location}`;
    container.appendChild(div);
  });
};
