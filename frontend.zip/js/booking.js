window.onload = async () => {
  const res = await fetch('http://localhost:5002/api/bookings');
  const bookings = await res.json();
  const container = document.getElementById('bookingList');
  bookings.forEach(b => {
    const div = document.createElement('div');
    div.textContent = `${b.user.name} booked ${b.services.join(', ')} at ${b.timeSlot}`;
    container.appendChild(div);
  });
  window.onload = async () => {
  const token = localStorage.getItem('token');
  const res = await fetch('http://localhost:5002/api/bookings', {
    headers: {
      Authorization: `Bearer ${token}`
    }
  });
  const bookings = await res.json();
  const container = document.getElementById('bookingList');
  bookings.forEach(b => {
    const div = document.createElement('div');
    div.textContent = `${b.user.name} booked ${b.services.join(', ')} at ${b.timeSlot}`;
    container.appendChild(div);
  });
};

};